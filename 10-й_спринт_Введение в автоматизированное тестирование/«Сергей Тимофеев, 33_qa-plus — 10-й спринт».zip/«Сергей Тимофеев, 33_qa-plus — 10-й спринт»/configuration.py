# URL_SERVICE хранит базовый URL веб-сервиса, который используется для доступа к API или другим ресурсам.
URL_SERVICE = "https://a8eb3084-fd20-4236-af8a-c6728826443f.serverhub.praktikum-services.ru"

#ручка создания нового пользователя
CREATE_USER_PATH = "/api/v1/users/"
#ручка создания набора
CREATE_KITS_PATH = "/api/v1/kits/"
