# Базовые поля пользователя
user_body = {
    "firstName": "Аа",
    "phone": "+79995553322",
    "address": "г. Москва, ул. Пушкина, д. 10"
}
kits_body = {
    "name": "Коля"
}

kits_headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer authtoken"
}
